/*
 * Jannatul Mahmud
 * Midterm Project - Cave Diver
 */

class CaveCell {
    private int row, col, depth, randomNumber;
    private boolean isEscapeRoute;

    /**
     * Constructor to initialize the cave cell with the given row, column, and depth.
     *
     * @param row The row position of the cell in the grid.
     * @param col The column position of the cell in the grid.
     * @param depth The depth level of the cell.
     */
    public CaveCell(int row, int col, int depth) {
        this.row = row;
        this.col = col;
        this.depth = depth;
        this.isEscapeRoute = false;
    }

    /**
     * Gets the depth of the cave cell.
     *
     * @return The depth of the cave cell.
     */
    public int getDepth() {
    	return depth; 
    	}
    
    /**
     * Checks if the cell is part of the escape route.
     *
     * @return true if the cell is part of the escape route, false otherwise.
     */
    public boolean isEscapeRoute() {
    	return isEscapeRoute; 
    	}
    
    /**
     * Sets the escape route status of the cell.
     *
     * @param escapeRoute The escape route status to set.
     */
    public void setEscapeRoute(boolean escapeRoute) {
    	isEscapeRoute = escapeRoute; 
    	}
    // Getter for the random number
    public int getRandomNumber() {
    	return randomNumber; 
    }
}
