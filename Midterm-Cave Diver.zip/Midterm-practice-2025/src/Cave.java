/*
 * Jannatul Mahmud
 * Midterm Project - Cave Diver
 */

import java.util.Random;

class Cave {
    private static final int SIZE = 10;
    private static final int AIR_LIMIT = 20;
    private CaveCell[][] grid;
    private int airRemaining;

    public Cave() {
        generateNewCave();
        this.airRemaining = AIR_LIMIT;
    }

    public void generateNewCave() {
        grid = new CaveCell[SIZE][SIZE];
        Random rand = new Random();
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                grid[i][j] = new CaveCell(i, j, rand.nextInt(10) + 1);
            }
        }
        this.airRemaining = AIR_LIMIT; // Reset air for a new cave
    }

    
    /**
     * Finds an escape path in the cave, starting from the top-left corner.
     *
     * @param maxDepth The maximum depth allowed to follow during the search.
     * @return true if an escape path is found, false otherwise.
     */
    public boolean findEscapePath(int maxDepth) {
        resetPath();
        return explorePath(0, 0, maxDepth, airRemaining);
    }
    
    

    /**
     * Explores the cave grid recursively to find an escape path.
     *
     * @param row The current row position.
     * @param col The current column position.
     * @param maxDepth The maximum depth allowed during the search.
     * @return true if an escape path is found, false otherwise.
     */
    private boolean explorePath(int row, int col, int maxDepth, int remainingAir) {
        if (row >= SIZE || col >= SIZE || grid[row][col].getDepth() > maxDepth || remainingAir <= 0) 
            return false;

        if (row == SIZE - 1 && col == SIZE - 1) {
            grid[row][col].setEscapeRoute(true);
            return true;
        }

        if (explorePath(row, col + 1, maxDepth, remainingAir - 1) || explorePath(row + 1, col, maxDepth, remainingAir - 1)) {
            grid[row][col].setEscapeRoute(true);
            return true;
        }

        return false;
    }

    private void resetPath() {
        for (CaveCell[] row : grid) 
            for (CaveCell cell : row) 
                cell.setEscapeRoute(false);
    }

    
    /**
     * Gets the cave grid.
     *
     * @return The 2D array representing the cave grid.
     */
    public CaveCell[][] getGrid() {
    	return grid;
    }
}
