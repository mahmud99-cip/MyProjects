/*
 * Jannatul Mahmud
 * Midterm Project - Cave Diver
 */

import javax.swing.*;
import java.awt.*;

public class CaveDiverApp extends JFrame {
    private Cave cave = new Cave();
    private CavePanel cavePanel = new CavePanel(cave);
    private JTextField depthInput = new JTextField(5);

    
    // Constructor to set up the user interface.
    public CaveDiverApp() {
        setupUI();
        setTitle("Cave Diver Escape");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
    }

    private void setupUI() {
        setLayout(new BorderLayout(10, 10));
        
        // Header
        add(new JLabel("Help the diver escape! Enter depth rating (1-10):", SwingConstants.CENTER), BorderLayout.NORTH);
        
        // Cave display
        add(cavePanel, BorderLayout.CENTER);

        // Control panel
        JPanel controls = new JPanel();
        controls.add(new JLabel("Enter the Diver's depth rating:"));
        controls.add(depthInput);
        
        JButton escapeBtn = new JButton("Find Escape");
        escapeBtn.addActionListener(e -> findEscape());
        controls.add(escapeBtn);

        JButton newCaveBtn = new JButton("New Cave");
        newCaveBtn.addActionListener(e -> newCave());
        controls.add(newCaveBtn);

        add(controls, BorderLayout.SOUTH);
    }

    
    /**
     * Finds the escape path based on the depth rating entered by the user.
     */
    private void findEscape() {
        try {
            int rating = Integer.parseInt(depthInput.getText());
            boolean found = cave.findEscapePath(rating);
            cavePanel.repaint();
            
            if (!found) 
                JOptionPane.showMessageDialog(this, "No escape path found with depth " + rating + "!", "No Path", JOptionPane.WARNING_MESSAGE);
            
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a number between 1-10", "Ouch", JOptionPane.ERROR_MESSAGE);
        }
    }

    
    /**
     * Generates a new cave and repaints the panel.
     */
    private void newCave() {
        cave.generateNewCave();
        cavePanel.repaint();
    }

    
    /**
     * Main method to start the application.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CaveDiverApp().setVisible(true));
    }
}