/*
 * Jannatul Mahmud
 * Midterm Project - Cave Diver
 */

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JPanel;

class CavePanel extends JPanel {
    private Cave cave;
    private final int CELL_SIZE = 50;

    
    /**
     * Constructor to initialize the cave panel with the given cave.
     *
     * @param cave The cave object to visualize.
     */
    public CavePanel(Cave cave) {
        this.cave = cave;
        setPreferredSize(new Dimension(CELL_SIZE * 10, CELL_SIZE * 10));
    }
  

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        CaveCell[][] grid = cave.getGrid();
        
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                CaveCell cell = grid[i][j];
                int x = j * CELL_SIZE;
                int y = i * CELL_SIZE;

                // Set color based on escape route or depth
                if (cell.isEscapeRoute()) {
                    g.setColor(Color.RED);
                } else {
                    int blue = 255 - cell.getDepth() * 25;
                    g.setColor(new Color(0, 0, Math.max(blue, 0)));
                }
                g.fillRect(x, y, CELL_SIZE, CELL_SIZE);

                // Draw cell border
                g.setColor(Color.BLACK);
                g.drawRect(x, y, CELL_SIZE, CELL_SIZE);

                // Draw the depth value at the top-left corner of each cell
                g.setColor(Color.WHITE); // Text color (white for better contrast)
                g.drawString(String.valueOf(cell.getDepth()), x + 2, y + 12); // Position the text near the top-left corner
            }
        }
    }

}
